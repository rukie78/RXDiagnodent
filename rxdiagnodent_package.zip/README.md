# RXDiagnodent

**AI-assisted dental diagnostic system** developed by **Marius Raducanu**.

RXDiagnodent combines deep learning image classification with symptom analysis to detect dental pathologies per tooth based on panoramic X-rays. This project is intended for educational and research purposes only.

## Features
- CNN-based image analysis
- Per-tooth classification (FDI numbering)
- Suggested treatment planning
- Symptom score integration
- Geolocation-based clinic recommendation

## Author
**Marius Raducanu** - Creator and Architect of RXDiagnodent.
